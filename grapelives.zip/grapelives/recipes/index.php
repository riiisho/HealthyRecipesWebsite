<!doctype html>
<html lang="en-GB">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../assets/icons/logo.svg" rel="icon" type="image/png">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		<title>Grape Lives: Recipes</title>
	</head>
	<body>
		<header> 
			<?php include('../header.php'); ?>
		</header>
		<main>
			<section class="type-intro">
				<div class="intro-left">
					<?php
						$recipe = $_GET['recipe']; 
						$fh = fopen("../assets/recipes/$recipe/name.txt",'r'); 
						while ($line = fgets($fh)) { 
							if (strlen($line) == 2) { 
								echo("<br>"); } 
							else { 
								echo("<h2>$line</h2>"); }} 
					?>
					<div class="intro-bio">
						<p>
							<?php
								$fh = fopen("../assets/recipes/$recipe/description.txt",'r'); 
								while ($line = fgets($fh)) { 
									if (strlen($line) == 2) { 
										echo("<br>"); } 
									else { 
										echo($line); }} 
							?>
						</p>
					</div>
				</div>
				<div class="intro-right">
					<?php
						echo("<img class=thumbnail src=../assets/recipes/".$_GET['recipe']."/image.jpg alt=".$_GET['recipe'].">");
					?>
				</div>
			</section>
			<section class="content">
				<div class="content-left">
					<h3>Ingredients</h3>
					<ul class="lunch-ingredients-list">
						<?php
							$fh = fopen("../assets/recipes/$recipe/ingredients.txt",'r'); 
							while ($line = fgets($fh)) { 
								if (strlen($line) == 2) { 
									echo("<br>"); } 
								else { 
									echo($line); }} 
							echo($line);
						?>
					</ul>
				</div>
				<div class="content-right">
					<h3>Method</h3>
					<?php
						$fh = fopen("../assets/recipes/$recipe/method.txt",'r'); 
						while ($line = fgets($fh)) { 
							if (strlen($line) == 2) { 
								echo("<br>"); } 
							else { 
								echo("<p>$line</p>"); }} 
					?>
					<h3>Nutritional Information</h3>
					<?php
						$fh = fopen("../assets/recipes/$recipe/nutritional.txt",'r'); 
						while ($line = fgets($fh)) { 
							if (strlen($line) == 2) { 
								echo("<br>"); } 
							else { 
								echo($line); }} 
					?>
				</div>
			</section>
		</main>
		<footer>
			<?php include('../footer.php'); ?>
		</footer>
	</body>
</html>