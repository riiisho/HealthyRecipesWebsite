<!doctype html>
<html lang="en-GB">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../assets/icons/logo.svg" rel="icon" type="image/png">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		<script>
			function myFunction() {
				console.log("myFunction() is running...");
				alert("You have been HACKED! Send me bitcoins.");
				
				document.getElementById("title").innerText="Hacked";
				document.getElementById("contact_form_form").style="font-family: Wingdings"; }
			function feedback() {
				document.getElementById("feedback").classList.remove("invisible");
				return false; }
		</script>
		<title>Grape Lives: Contact Page</title>
	</head>
	<body>
		<header> 
			<?php include('../header.php'); ?>
		</header>
		<main>
			<section class="type-a">
				<h2>Contact Us</h2>
				<div class="info">
					<p>Please use this form to send us a message.</p>
				</div>
				<section id="feedback" class="invisible">
					<h3>We have received your message and will reply soon.</h3>
				</section>
			</section>
			<section id="contact_form">
				<form id="contact_form_form" onSubmit="return feedback()">
					<label for="email">Email</label>
					<input type="email" name="email" id="email" class="forminput" value="" tabindex="1" required>
					<span class="invisible"><b>Incorrect Email Format:</b> Please Try Again</span>
	
					<label for="email">Feedback</label>
					<textarea cols="60" rows="8" name="textarea" id="textarea" class="forminput" required></textarea>

					<input type="submit" id="submit">	
				</form>
			</section>
			<section class="map">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5750.54857708738!2d-2.4994219477780217!3d52.69956274602386!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48707f87aad783cb%3A0x87c07443af6a1a0c!2sTelford%20College!5e0!3m2!1sen!2suk!4v1706697265609!5m2!1sen!2suk" id="map" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			</section>
		</main>
		<footer>
			<?php include('../footer.php'); ?>
		</footer>
	</body>
</html>