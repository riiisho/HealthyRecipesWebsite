<!doctype html>
<html lang="en-GB">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="../assets/icons/logo.svg" rel="icon" type="image/png">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		<title>Grape Lives: Account Page</title>
	</head>
	<body style="background: url(../assets/kiwis.jpg) no-repeat; background-size: cover; background-position: center;">
		<header> 
			<?php include('../header.php'); ?>
		</header>
		<main>
			<section class="wrapper">
				<form action="">
					<h1>Login</h1>
					<div class="input-box">
						<input type="text" placeholder="Username" required>
						<i class='bx bxs-user'></i>
					</div>
					<div class="input-box">
						<input type="password" placeholder="Password" required>
						<i class='bx bxs-lock-alt'></i>
					</div>
					<div class="remember-forget">
						<label><input type="checkbox">Remember me</label>
						<a href="#">Forgot password?</a>
					</div>
					<button type="submit" class="btn">Login</button>
					<div class="register-link">
						<p>Don't have an account? <a href="#">Register</a></p>
					</div>
				</form>

			</section>
		</main>
	</body>
</html>