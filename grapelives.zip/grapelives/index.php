<!doctype html>
<html lang="en-GB">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link href="assets/icons/logo.svg" rel="icon" type="image/png">
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="css/style.css" rel="stylesheet" type="text/css">
		<title>Grape Lives: Home Page</title>
	</head>
	<body>
		<header> 
			<?php include('header.php'); ?>
		</header>
		<main style="margin-bottom: 0;">
			<section class="type-a">
				<h2 style="font-size: 36px; margin-bottom: 0;">Live Healthy</h2>
				<div class="info">
					<p style="margin-bottom: 4rem;">
						Have you ever thought about living a healthier life? <br>
						Well think no longer... <br>
						Here are 3 healthy recipes just for you! <br>
					</p>
				</div>
			</section>
			<section class="type-intro" style="background-color: var(--background-100); border-radius: 50px;">
				<div class="intro-left">
					<h2 style="font-size: 48px;">Cheats' Pizza <br>Calzone</h2>
					<div class="intro-bio">
						<p>
							Warm wholewheat wraps hold a delicious Italian-style <br>
							vegetable mixture, to give a lighter version of a folded pizza.
						</p>
					</div>
				</div>
				<div class="intro-right">
					<img class="thumbnail" src="assets/recipes/lunch/image.jpg" alt="An image of Cheats' Pizza Calzone Recipe"/>
				</div>
			</section>
			<section class="type-intro" style="background-color: var(--background-100); border-radius: 50px; flex-direction: row-reverse;">
				<div class="intro-left">
					<h2 style="font-size: 48px;">Bajan Cou Cou <br>with Spicy Fish</h2>
					<div class="intro-bio">
						<p>
							A low-fat adaptation of the delicious national dish of <br>Barbados –
							cornmeal and okra, served with marinated <br>
							fish in a tasty spicy sauce.
						</p>
					</div>
				</div>
				<div class="intro-right">
					<img class="thumbnail" src="assets/recipes/dinner/image.jpg" alt="An image of Bajan Cou Cou with Spicy Fish Recipe"/>
				</div>
			</section>
			<section class="type-intro" style="background-color: var(--background-100); border-radius: 50px;">
				<div class="intro-left">
					<h2 style="font-size: 48px;">Sweet Potato Chips <br>with Simple Salsa</h2>
					<div class="intro-bio">
						<p>
							Perfect served with a side salad or as a snack to share. <br>
							For a twist, try roasting pumpkin or butternut squash instead.
						</p>
					</div>
				</div>
				<div class="intro-right">
					<img class="thumbnail" src="assets/recipes/snack/image.jpg" alt="An image of Sweet Potato Chips with Simple Salsa Recipe"/>
				</div>
			</section>
			<section class="type-a">
				<h2 style="font-size: 36px; margin-bottom: 0;">Sign Up Now</h2>
				<div class="info">
					<p style="margin-bottom: 4rem; font-size: 24px; ">
						To be notified of more healthy recipes!
					</p>
				</div>
			</section>
			<section class="youtube-embed" style="aspect-ratio: 16 / 9; width: 100%; margin-bottom: 50px;">
				<iframe id="youtube-embed" width="100%" height="100%" src="https://www.youtube.com/embed/hapjShCi254" title="How to ACTUALLY start cooking Healthy Food - 5 habits" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
			</section>
		</main>
		<footer>
			<?php include('footer.php'); ?>
		</footer>
	</body>
</html>