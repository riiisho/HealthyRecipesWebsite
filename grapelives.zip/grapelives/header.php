<!doctype html>
<html lang="en-GB">
<nav class="header__nav"> 
	<div class="header__logo">
		<a href="/grapelives"><h1>Grape Lives</h1></a>
	</div>
	<ul class="header__list">
		<li>
			<a href="/grapelives/contact/">Contact</a>
		</li>
		<li class="dropdown">
			<button class="dropbtn">
				Recipes
				<img src="/grapelives/assets/icons/dropdown.svg" alt="Dropdown"/>
			</button>
			<div class="dropdown-content">
				<a href="/grapelives/recipes/?recipe=lunch">Lunch</a>
				<a href="/grapelives/recipes/?recipe=dinner">Dinner</a>
				<a href="/grapelives/recipes/?recipe=snack">Snack</a>
			</div>
		</li>
		<li class="header__icon">
			<a href="/grapelives/account/" style="margin: 0px; padding-right: 12px;">Account</a>
			<a href="/grapelives/account/" style="margin: 0px; padding-right: 12px;"><img src="/grapelives/assets/icons/account.svg" alt="Account"/></a>
		</li>
	</ul>
	<ul class="header__list-mobile">
		<li class="dropdown-mobile">
			<button class="dropbtn-mobile">
				<img src="/grapelives/assets/icons/menu.svg" alt="Menu">
			</button>
			<div class="dropdown-content-mobile">
				<a href="/grapelives/contact/">Contact</a>
				<a href="/grapelives/recipes/?recipe=lunch">Lunch Recipe</a>
				<a href="/grapelives/recipes/?recipe=dinner">Dinner Recipe</a>
				<a href="/grapelives/recipes/?recipe=snack">Snack Recipe</a>
				<a href="/grapelives/account/">Account</a>
			</div>
		</li>
	</ul>
</nav>
</html>