<!doctype html>
<html lang="en-GB">
	<nav class="footer__nav"> 
		<div class="footer__list">
			<div class="footer__list_explore">
				<h3>Explore</h3>
				<a href="#questions">Frequently Asked Questions</a>
				<a href="/grapelives/account/">Account</a>
				<a href="/grapelives/recipes/?recipe=lunch">Lunch Recipe</a>
				<a href="/grapelives/recipes/?recipe=dinner">Dinner Recipe</a>
				<a href="/grapelives/recipes/?recipe=snack">Snack Recipe</a>
			</div>
			<div class="footer__list_contact">
				<h3>Get in Contact</h3>
				<a href="/grapelives/contact">Contact Us</a>
				<a href="#about">About Us</a>
				<a href="#share">Share</a>
			</div>
		</div>
		<div class="footer__caption">
			<p style="color: #515151; font-size: 0.83em; font-weight: bold;">© 2024 Grape Lives. All Rights Reserved</h5>
		</div>
	</nav>
</html>